菜價中繼安裝包
public/index.html            已把 VEG_URL 改成 '/veg.json'
scripts/fetch_veg.py         抓農業部菜價
.github/workflows/veg.yml    排程（隱藏資料夾，網頁上傳時請改用「貼上內容」方式建立）
貼到GitHub的_veg.yml.txt     與 veg.yml 內容相同，方便複製貼上
